import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
    format, startOfWeek, endOfWeek, eachDayOfInterval,
    addWeeks, subWeeks, isSameDay, parseISO, addDays, subDays, isWithinInterval,
} from 'date-fns';
import { ru } from 'date-fns/locale';
import api from '../api/api';
import { Header } from '../Components/Layout/Header';
import { Card } from '../Components/UI/Card';
import { Button } from '../Components/UI/Button';
import { Modal } from '../Components/UI/Modal';
import { Input } from '../Components/UI/Input';
import { Spinner } from '../Components/UI/Spinner';
import { useToast } from '../Hooks/useToast';

// ─── Types ────────────────────────────────────────────────────────────────────
interface Procedure {
    procedureId: string; patientCardId: string; typeId: string;
    doctorId?: string | null; title: string; scheduledDate: string;
    price: number; duration?: number;
}
interface PatientCard { id: string; patientId: string; fullname: string; age: number; phoneNumber: string; }
interface ProcedureType { id: string; title: string; duration: number; price: number; }
interface Doctor { id: string; name: string; }
type ViewMode = 'day' | 'week';

// ─── Searchable dropdown ──────────────────────────────────────────────────────
interface DropdownItem { id: string; label: string; sub?: string; }
interface SearchDropdownProps {
    label: string; required?: boolean; optional?: boolean; hint?: string;
    placeholder: string; value: string;
    onChange: (v: string) => void;
    items: DropdownItem[];
    onSelect: (id: string, label: string) => void;
    selectedLabel?: string;
}

const SearchDropdown: React.FC<SearchDropdownProps> = ({
    label, required, optional, hint, placeholder, value, onChange, items, onSelect, selectedLabel,
}) => {
    const [open, setOpen] = useState(false);
    const ref = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
        document.addEventListener('mousedown', h);
        return () => document.removeEventListener('mousedown', h);
    }, []);

    const filtered = useMemo(() => {
        if (!value.trim()) return items;
        const q = value.toLowerCase();
        return items.filter(i => i.label.toLowerCase().includes(q));
    }, [items, value]);

    return (
        <div className="form-group" ref={ref}>
            <label className="form-label">
                {label}{' '}
                {required && <span style={{ color: 'var(--color-danger)' }}>*</span>}
                {optional && <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}> (необязательно)</span>}
            </label>
            {hint && <p style={{ fontSize: '.75rem', color: 'var(--text-muted)', marginBottom: '.375rem' }}>{hint}</p>}
            <div style={{ position: 'relative' }}>
                <input
                    type="text"
                    placeholder={placeholder}
                    value={value}
                    onChange={e => { onChange(e.target.value); setOpen(true); }}
                    onFocus={() => setOpen(true)}
                    autoComplete="off"
                    className="form-input"
                />
                {open && filtered.length > 0 && (
                    <div style={{
                        position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 200,
                        background: 'var(--bg-surface)', border: '1px solid var(--border-default)',
                        borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-lg)',
                        maxHeight: 220, overflowY: 'auto', marginTop: 4,
                    }}>
                        {filtered.map(item => (
                            <button
                                key={item.id} type="button"
                                onClick={() => { onSelect(item.id, item.label); setOpen(false); }}
                                style={{
                                    display: 'block', width: '100%', textAlign: 'left',
                                    padding: '.625rem 1rem', background: 'none', border: 'none', cursor: 'pointer',
                                    transition: 'background var(--transition-fast)',
                                }}
                                onMouseEnter={e => (e.currentTarget.style.background = 'var(--bg-muted)')}
                                onMouseLeave={e => (e.currentTarget.style.background = 'none')}
                            >
                                <div style={{ fontSize: '.875rem', fontWeight: 500, color: 'var(--text-primary)' }}>{item.label}</div>
                                {item.sub && <div style={{ fontSize: '.75rem', color: 'var(--text-muted)', marginTop: 1 }}>{item.sub}</div>}
                            </button>
                        ))}
                    </div>
                )}
            </div>
            {selectedLabel && !open && (
                <p style={{
                    marginTop: '.375rem', fontSize: '.8125rem', fontWeight: 600,
                    color: 'var(--color-success)', padding: '.375rem .75rem',
                    background: 'var(--color-success-light)', borderRadius: 'var(--radius-sm)',
                    display: 'inline-block',
                }}>
                    ✓ {selectedLabel}
                </p>
            )}
        </div>
    );
};

// ─── Page ─────────────────────────────────────────────────────────────────────
const SchedulePage: React.FC = () => {
    const { showSuccess, showError } = useToast();
    const [currentDate, setCurrentDate] = useState(new Date());
    const [viewMode, setViewMode] = useState<ViewMode>('week');
    const [procedures, setProcedures] = useState<Procedure[]>([]);
    const [selectedProcedure, setSelectedProcedure] = useState<Procedure | null>(null);
    const [isDetailsOpen, setIsDetailsOpen] = useState(false);
    const [isAddOpen, setIsAddOpen] = useState(false);
    const [patients, setPatients] = useState<PatientCard[]>([]);
    const [procedureTypes, setProcedureTypes] = useState<ProcedureType[]>([]);
    const [doctors, setDoctors] = useState<Doctor[]>([]);
    const [loadingRef, setLoadingRef] = useState(false);
    const [formLoading, setFormLoading] = useState(false);
    const [deleteTarget, setDeleteTarget] = useState<string | null>(null);

    const [dateRange, setDateRange] = useState({
        start: startOfWeek(new Date(), { weekStartsOn: 1 }),
        end:   endOfWeek(new Date(),   { weekStartsOn: 1 }),
    });

    // Form state
    const [form, setForm] = useState({ patientCardId: '', typeId: '', doctorId: '', scheduledDate: '', price: '' });
    const [search, setSearch] = useState({ patient: '', type: '', doctor: '' });

    const weekDays  = useMemo(() => eachDayOfInterval({ start: dateRange.start, end: dateRange.end }), [dateRange]);
    const dayHours  = Array.from({ length: 13 }, (_, i) => i + 8);

    const loadReferenceData = async () => {
        setLoadingRef(true);
        try {
            const [p, t, d] = await Promise.all([
                api.get('/PatientCards/All'),
                api.get('/ProcedureTypes/All'),
                api.get('/Doctors/All'),
            ]);
            setPatients(Array.isArray(p.data) ? p.data : []);
            setProcedureTypes(Array.isArray(t.data) ? t.data : []);
            setDoctors(Array.isArray(d.data) ? d.data : []);
        } catch { showError('Ошибка загрузки справочных данных'); }
        finally { setLoadingRef(false); }
    };

    const fetchProcedures = async () => {
        try {
            const r = await api.get('/Procedures/All');
            const data = (Array.isArray(r.data) ? r.data : []).filter((p: Procedure) => {
                if (!p.scheduledDate) return false;
                return isWithinInterval(parseISO(p.scheduledDate), { start: dateRange.start, end: dateRange.end });
            });
            setProcedures(data);
        } catch { showError('Ошибка загрузки процедур'); }
    };

    useEffect(() => { loadReferenceData(); }, []);
    useEffect(() => { fetchProcedures(); }, [dateRange]);

    const hasConflict = (proc: Procedure) => {
        const d1 = parseISO(proc.scheduledDate);
        const dur1 = proc.duration || 60;
        const end1 = new Date(d1.getTime() + dur1 * 60000);
        return procedures.some(p => {
            if (p.procedureId === proc.procedureId || !p.scheduledDate) return false;
            const d2 = parseISO(p.scheduledDate);
            const end2 = new Date(d2.getTime() + (p.duration || 60) * 60000);
            return d1 < end2 && end1 > d2;
        });
    };

    const navigate = (dir: 1 | -1) => {
        const fn = viewMode === 'week'
            ? dir > 0 ? addWeeks : subWeeks
            : dir > 0 ? addDays  : subDays;
        const amount = viewMode === 'week' ? 1 : 1;
        setCurrentDate(fn(currentDate, amount));
        if (viewMode === 'week') {
            setDateRange({ start: fn(dateRange.start, amount), end: fn(dateRange.end, amount) });
        } else {
            const d = fn(currentDate, amount);
            setDateRange({ start: d, end: d });
        }
    };

    const goToday = () => {
        const t = new Date();
        setCurrentDate(t);
        setDateRange({
            start: viewMode === 'week' ? startOfWeek(t, { weekStartsOn: 1 }) : t,
            end:   viewMode === 'week' ? endOfWeek(t,   { weekStartsOn: 1 }) : t,
        });
    };

    const switchView = (mode: ViewMode) => {
        const t = new Date();
        setViewMode(mode);
        setCurrentDate(t);
        setDateRange({
            start: mode === 'week' ? startOfWeek(t, { weekStartsOn: 1 }) : t,
            end:   mode === 'week' ? endOfWeek(t,   { weekStartsOn: 1 }) : t,
        });
    };

    const handleAdd = async () => {
        if (!form.patientCardId) { showError('Выберите пациента'); return; }
        if (!form.typeId)        { showError('Выберите тип процедуры'); return; }
        if (!form.scheduledDate) { showError('Укажите дату и время'); return; }
        setFormLoading(true);
        try {
            await api.post('/Procedures', {
                patientCardId: form.patientCardId,
                typeId: form.typeId,
                doctorId: form.doctorId || null,
                scheduledDate: new Date(form.scheduledDate).toISOString(),
                price: parseInt(form.price) || 0,
                duration: 0,
            });
            setIsAddOpen(false);
            setForm({ patientCardId: '', typeId: '', doctorId: '', scheduledDate: '', price: '' });
            setSearch({ patient: '', type: '', doctor: '' });
            showSuccess('Запись успешно создана');
            fetchProcedures();
        } catch (e: any) {
            showError(e.response?.data?.message || 'Ошибка создания записи');
        } finally { setFormLoading(false); }
    };

    const handleDelete = async () => {
        if (!deleteTarget) return;
        try {
            await api.delete(`/Procedures/${deleteTarget}`);
            showSuccess('Запись удалена');
            fetchProcedures();
            setIsDetailsOpen(false);
        } catch { showError('Ошибка удаления'); }
        finally { setDeleteTarget(null); }
    };

    // DropdownItems helpers
    const patientItems  = useMemo(() => patients.map(p => ({ id: p.id, label: p.fullname, sub: `${p.phoneNumber ?? ''} • ${p.age ?? '?'} лет` })), [patients]);
    const typeItems     = useMemo(() => procedureTypes.map(t => ({ id: t.id, label: t.title, sub: `⏱ ${t.duration} мин  💰 ${t.price} ₽` })), [procedureTypes]);
    const doctorItems   = useMemo(() => doctors.map(d => ({ id: d.id, label: d.name })), [doctors]);

    const selPatient = patients.find(p => p.id === form.patientCardId);
    const selType    = procedureTypes.find(t => t.id === form.typeId);
    const selDoctor  = doctors.find(d => d.id === form.doctorId);

    const ProcedureCard = ({ proc, compact = false }: { proc: Procedure; compact?: boolean }) => {
        const conflict = hasConflict(proc);
        return (
            <div
                onClick={() => { setSelectedProcedure(proc); setIsDetailsOpen(true); }}
                style={{
                    padding: compact ? '.5rem .625rem' : '.625rem .875rem',
                    borderRadius: 'var(--radius-sm)',
                    cursor: 'pointer',
                    background: conflict
                        ? 'linear-gradient(135deg, #B84054, #C8865A)'
                        : 'linear-gradient(135deg, var(--color-primary), #A0607E)',
                    color: '#fff',
                    transition: 'all var(--transition-fast)',
                }}
                onMouseEnter={e => (e.currentTarget.style.transform = 'scale(1.02)')}
                onMouseLeave={e => (e.currentTarget.style.transform = '')}
            >
                <div style={{ fontWeight: 700, fontSize: compact ? '.75rem' : '.8125rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {proc.title || 'Процедура'}
                </div>
                <div style={{ fontSize: '.6875rem', opacity: .8, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {patients.find(p => p.id === proc.patientCardId)?.fullname ?? 'Пациент'}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 2, fontSize: '.6875rem', opacity: .7 }}>
                    <span>{proc.scheduledDate ? format(parseISO(proc.scheduledDate), 'HH:mm') : ''}</span>
                    <span>{proc.price ? `${proc.price} ₽` : ''}</span>
                </div>
                {conflict && <div style={{ fontSize: '.625rem', fontWeight: 700, color: '#FFD580', marginTop: 2 }}>⚠ Пересечение</div>}
            </div>
        );
    };

    const todayCount  = procedures.filter(p => p.scheduledDate && isSameDay(parseISO(p.scheduledDate), new Date())).length;
    const totalRev    = procedures.reduce((s, p) => s + (p.price || 0), 0);
    const conflictCnt = procedures.filter(p => hasConflict(p)).length;

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <Header
                title="Расписание"
                subtitle="Управление записями на процедуры"
                actions={
                    <Button onClick={() => { loadReferenceData(); setIsAddOpen(true); }} variant="success" isLoading={loadingRef}>
                        + Записать пациента
                    </Button>
                }
            />

            {/* Controls */}
            <Card>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
                    <div style={{ display: 'flex', gap: '.5rem', alignItems: 'center' }}>
                        <Button variant="outline" size="sm" onClick={() => navigate(-1)}>← Назад</Button>
                        <Button variant="outline" size="sm" onClick={goToday}>Сегодня</Button>
                        <Button variant="outline" size="sm" onClick={() => navigate(1)}>Вперёд →</Button>
                    </div>

                    <h2 style={{
                        fontFamily: "'Cormorant Garamond', serif",
                        fontSize: '1.125rem', fontWeight: 600, color: 'var(--text-primary)',
                    }}>
                        {viewMode === 'week'
                            ? `${format(dateRange.start, 'd MMMM', { locale: ru })} — ${format(dateRange.end, 'd MMMM yyyy', { locale: ru })}`
                            : format(currentDate, 'd MMMM yyyy', { locale: ru })}
                    </h2>

                    <div style={{
                        display: 'flex', background: 'var(--bg-muted)',
                        borderRadius: 'var(--radius-md)', padding: 4,
                    }}>
                        {(['day', 'week'] as ViewMode[]).map(m => (
                            <button key={m} onClick={() => switchView(m)}
                                style={{
                                    padding: '.4rem .875rem', borderRadius: 6, border: 'none', cursor: 'pointer',
                                    fontFamily: "'Nunito', sans-serif", fontWeight: 600, fontSize: '.8125rem',
                                    background: viewMode === m ? 'var(--bg-surface)' : 'transparent',
                                    color: viewMode === m ? 'var(--color-primary)' : 'var(--text-muted)',
                                    boxShadow: viewMode === m ? 'var(--shadow-sm)' : 'none',
                                    transition: 'all var(--transition-fast)',
                                }}>
                                {m === 'day' ? 'День' : 'Неделя'}
                            </button>
                        ))}
                    </div>
                </div>
            </Card>

            {/* Calendar */}
            {viewMode === 'week' ? (
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
                    {weekDays.map((day, i) => {
                        const dayProcs = procedures.filter(p => p.scheduledDate && isSameDay(parseISO(p.scheduledDate), day));
                        const isToday = isSameDay(day, new Date());
                        return (
                            <div key={i} className="card" style={{
                                minHeight: 140,
                                border: isToday ? '2px solid var(--color-primary)' : undefined,
                                overflow: 'hidden',
                            }}>
                                <div style={{
                                    textAlign: 'center', padding: '.625rem',
                                    background: isToday ? 'var(--color-primary-light)' : 'var(--bg-muted)',
                                    borderBottom: '1px solid var(--border-subtle)',
                                }}>
                                    <div style={{ fontSize: '.6875rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '.06em' }}>
                                        {format(day, 'EEE', { locale: ru })}
                                    </div>
                                    <div style={{
                                        fontFamily: "'Cormorant Garamond', serif",
                                        fontSize: '1.5rem', fontWeight: 700,
                                        color: isToday ? 'var(--color-primary)' : 'var(--text-primary)',
                                    }}>
                                        {format(day, 'd')}
                                    </div>
                                </div>
                                <div style={{ padding: '.5rem', display: 'flex', flexDirection: 'column', gap: '.375rem' }}>
                                    {dayProcs.length === 0
                                        ? <div style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: '.75rem', padding: '1rem 0' }}>Нет записей</div>
                                        : dayProcs.map(p => <ProcedureCard key={p.procedureId} proc={p} compact />)
                                    }
                                </div>
                            </div>
                        );
                    })}
                </div>
            ) : (
                <Card noPadding>
                    <div>
                        {dayHours.map(hour => {
                            const slotProcs = procedures.filter(p => {
                                if (!p.scheduledDate) return false;
                                const d = parseISO(p.scheduledDate);
                                return isSameDay(d, currentDate) && d.getHours() === hour;
                            });
                            return (
                                <div key={hour} style={{
                                    display: 'flex', minHeight: 72,
                                    background: slotProcs.some(p => hasConflict(p)) ? 'rgba(184,64,84,.04)' : undefined,
                                    borderBottom: '1px solid var(--border-subtle)',
                                }}>
                                    <div style={{
                                        width: 72, flexShrink: 0, padding: '.875rem .5rem',
                                        textAlign: 'center', borderRight: '1px solid var(--border-subtle)',
                                        background: 'var(--bg-muted)',
                                    }}>
                                        <div style={{ fontSize: '.8125rem', fontWeight: 700, color: 'var(--text-secondary)' }}>
                                            {String(hour).padStart(2, '0')}:00
                                        </div>
                                    </div>
                                    <div style={{ flex: 1, padding: '.5rem .75rem', display: 'flex', flexDirection: 'column', gap: '.375rem' }}>
                                        {slotProcs.length === 0
                                            ? <div style={{ display: 'flex', alignItems: 'center', height: '100%', color: 'var(--text-muted)', fontSize: '.8125rem' }}>Свободно</div>
                                            : slotProcs.map(p => <ProcedureCard key={p.procedureId} proc={p} />)
                                        }
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </Card>
            )}

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                    { label: 'Сегодня', value: todayCount,                        color: 'var(--color-primary)' },
                    { label: 'За период', value: procedures.length,               color: 'var(--color-accent)' },
                    { label: 'Выручка', value: `${totalRev.toLocaleString('ru-RU')} ₽`, color: 'var(--color-success)' },
                    { label: 'Пересечений', value: conflictCnt,                   color: conflictCnt > 0 ? 'var(--color-danger)' : 'var(--text-muted)' },
                ].map(s => (
                    <div key={s.label} className="card" style={{ padding: '1.25rem', textAlign: 'center' }}>
                        <p style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.75rem', fontWeight: 700, color: s.color }}>{s.value}</p>
                        <p style={{ fontSize: '.75rem', color: 'var(--text-muted)', marginTop: '.25rem' }}>{s.label}</p>
                    </div>
                ))}
            </div>

            {/* Details Modal */}
            <Modal isOpen={isDetailsOpen} onClose={() => setIsDetailsOpen(false)} title="Детали записи" size="sm"
                footer={selectedProcedure && (
                    <>
                        <Button variant="outline" onClick={() => setIsDetailsOpen(false)}>Закрыть</Button>
                        <Button variant="danger" onClick={() => { setDeleteTarget(selectedProcedure.procedureId); setIsDetailsOpen(false); }}>Удалить</Button>
                    </>
                )}>
                {selectedProcedure && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                        {[
                            { label: 'Процедура', value: selectedProcedure.title },
                            { label: 'Дата и время', value: selectedProcedure.scheduledDate ? format(parseISO(selectedProcedure.scheduledDate), 'dd MMMM yyyy, HH:mm', { locale: ru }) : '—' },
                            { label: 'Пациент', value: patients.find(p => p.id === selectedProcedure.patientCardId)?.fullname ?? '—' },
                            { label: 'Врач',     value: doctors.find(d => d.id === selectedProcedure.doctorId)?.name ?? 'Не назначен' },
                            { label: 'Стоимость', value: selectedProcedure.price ? `${selectedProcedure.price} ₽` : '—' },
                        ].map(r => (
                            <div key={r.label}>
                                <p style={{ fontSize: '.75rem', color: 'var(--text-muted)', marginBottom: '.25rem' }}>{r.label}</p>
                                <p style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{r.value}</p>
                            </div>
                        ))}
                    </div>
                )}
            </Modal>

            {/* Delete confirm */}
            <Modal isOpen={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Удалить запись?" size="sm"
                footer={<><Button variant="outline" onClick={() => setDeleteTarget(null)}>Отмена</Button><Button variant="danger" onClick={handleDelete}>Удалить</Button></>}>
                <p style={{ color: 'var(--text-secondary)' }}>Эта запись будет удалена безвозвратно.</p>
            </Modal>

            {/* Add Modal */}
            <Modal isOpen={isAddOpen} onClose={() => setIsAddOpen(false)} title="Запись на процедуру" size="lg"
                footer={<>
                    <Button variant="outline" onClick={() => setIsAddOpen(false)} disabled={formLoading}>Отмена</Button>
                    <Button variant="success" onClick={handleAdd} isLoading={formLoading}>Записать</Button>
                </>}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '.25rem', maxHeight: '65vh', overflowY: 'auto', paddingRight: 4 }}>
                    {loadingRef ? <Spinner /> : (
                        <>
                            <SearchDropdown label="Пациент" required placeholder="Иванов Иван..." hint="Начните вводить ФИО для поиска"
                                value={search.patient} onChange={v => setSearch(s => ({ ...s, patient: v }))}
                                items={patientItems} selectedLabel={selPatient?.fullname}
                                onSelect={(id, label) => { setForm(f => ({ ...f, patientCardId: id })); setSearch(s => ({ ...s, patient: label })); }}
                            />
                            <SearchDropdown label="Тип процедуры" required placeholder="Консультация, пилинг..." hint="Стоимость подставится автоматически"
                                value={search.type} onChange={v => setSearch(s => ({ ...s, type: v }))}
                                items={typeItems} selectedLabel={selType?.title}
                                onSelect={(id, label) => {
                                    const t = procedureTypes.find(x => x.id === id);
                                    setForm(f => ({ ...f, typeId: id, price: String(t?.price ?? 0) }));
                                    setSearch(s => ({ ...s, type: label }));
                                }}
                            />
                            <SearchDropdown label="Врач" optional placeholder="Петрова Наталья..." hint="Оставьте пустым, если врач не назначен"
                                value={search.doctor} onChange={v => setSearch(s => ({ ...s, doctor: v }))}
                                items={doctorItems} selectedLabel={selDoctor?.name}
                                onSelect={(id, label) => { setForm(f => ({ ...f, doctorId: id })); setSearch(s => ({ ...s, doctor: label })); }}
                            />
                            <Input label="Дата и время" required type="datetime-local"
                                value={form.scheduledDate} min={new Date().toISOString().slice(0, 16)}
                                onChange={e => setForm(f => ({ ...f, scheduledDate: e.target.value }))}
                            />
                            <Input label="Стоимость (₽)" type="number" min="0" placeholder="0"
                                value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))}
                            />
                        </>
                    )}
                </div>
            </Modal>
        </div>
    );
};

export default SchedulePage;
