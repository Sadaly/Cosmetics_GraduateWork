import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api/api";

interface RecentProcedure {
    procedureId: string;
    patientCardId: string;
    price: number;
    scheduledDate?: string;
    typeId: string;
    title: string;
    doctorId?: string;
    isComplete: boolean;
    isCancelled: boolean;
}

interface RecentPatient {
    patientId: string;
    fullname: string;
    cardId: string;
    age: number;
    creationDate: string;
}

const HomePage: React.FC = () => {
    const [procedures, setProcedures] = useState<RecentProcedure[]>([]);
    const [patients, setPatients] = useState<RecentPatient[]>([]);
    const [loadingProcs, setLoadingProcs] = useState(true);
    const [loadingPats, setLoadingPats] = useState(true);
    const [userEmail, setUserEmail] = useState<string>("");
    const navigate = useNavigate();

    useEffect(() => {
        // Fetch current user info
        api.get("/Users/Me")
            .then(r => setUserEmail(r.data?.email || ""))
            .catch(() => {});

        // Fetch recent procedures (last 8)
        api.get("/Procedures/Take", { params: { StartIndex: 0, Count: 8 } })
            .then(r => {
                const data = Array.isArray(r.data) ? r.data : [];
                // Sort by scheduledDate or creationDate descending
                data.sort((a: RecentProcedure, b: RecentProcedure) => {
                    const da = a.scheduledDate ? new Date(a.scheduledDate).getTime() : 0;
                    const db = b.scheduledDate ? new Date(b.scheduledDate).getTime() : 0;
                    return db - da;
                });
                setProcedures(data);
            })
            .catch(() => setProcedures([]))
            .finally(() => setLoadingProcs(false));

        // Fetch recent patients (last 5)
        api.get("/Patients/Take", { params: { StartIndex: 0, Count: 5 } })
            .then(r => {
                const data = Array.isArray(r.data) ? r.data : [];
                data.sort((a: RecentPatient, b: RecentPatient) => {
                    const da = a.creationDate ? new Date(a.creationDate).getTime() : 0;
                    const db = b.creationDate ? new Date(b.creationDate).getTime() : 0;
                    return db - da;
                });
                setPatients(data);
            })
            .catch(() => setPatients([]))
            .finally(() => setLoadingPats(false));
    }, []);

    const formatDate = (iso?: string) => {
        if (!iso) return "—";
        const d = new Date(iso);
        return isNaN(d.getTime()) ? "—" : d.toLocaleString("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
    };

    const getProcedureStatus = (p: RecentProcedure) => {
        if (p.isCancelled) return { label: "Отменена", color: "#ef4444" };
        if (p.isComplete) return { label: "Завершена", color: "#10b981" };
        return { label: "Ожидается", color: "#f59e0b" };
    };

    return (
        <div style={{ padding: "2rem", maxWidth: 1200, margin: "0 auto" }}>
            {/* Header */}
            <div style={{ marginBottom: "2rem" }}>
                <h1 style={{ margin: 0, color: "#1e293b", fontSize: "1.8rem" }}>Главная</h1>
                {userEmail && (
                    <p style={{ margin: "4px 0 0", color: "#64748b", fontSize: "0.95rem" }}>
                        Вы вошли как <strong>{userEmail}</strong>
                    </p>
                )}
            </div>

            {/* Quick navigation cards */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "1rem", marginBottom: "2rem" }}>
                {[
                    { to: "/patients", label: "Пациенты", emoji: "👤", color: "#3b82f6" },
                    { to: "/schedule", label: "Расписание", emoji: "📅", color: "#8b5cf6" },
                    { to: "/analitics", label: "Аналитика", emoji: "📊", color: "#10b981" },
                    { to: "/users", label: "Пользователи", emoji: "🔧", color: "#f59e0b" },
                ].map(({ to, label, emoji, color }) => (
                    <Link
                        key={to}
                        to={to}
                        style={{
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            gap: 8,
                            padding: "1.2rem",
                            background: "white",
                            borderRadius: 12,
                            boxShadow: "0 2px 8px rgba(0,0,0,0.07)",
                            border: `2px solid ${color}22`,
                            textDecoration: "none",
                            color: "#1e293b",
                            fontWeight: 600,
                            fontSize: "0.95rem",
                            transition: "box-shadow 0.2s",
                        }}
                        onMouseOver={e => (e.currentTarget.style.boxShadow = `0 4px 16px ${color}44`)}
                        onMouseOut={e => (e.currentTarget.style.boxShadow = "0 2px 8px rgba(0,0,0,0.07)")}
                    >
                        <span style={{ fontSize: "1.8rem" }}>{emoji}</span>
                        <span style={{ color }}>{label}</span>
                    </Link>
                ))}
            </div>

            {/* Last activity — two columns */}
            <h2 style={{ color: "#1e293b", fontSize: "1.2rem", marginBottom: "1rem" }}>Последняя активность</h2>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.5rem" }}>

                {/* Recent procedures */}
                <div style={{ background: "white", borderRadius: 12, padding: "1.2rem", boxShadow: "0 2px 8px rgba(0,0,0,0.07)" }}>
                    <h3 style={{ margin: "0 0 1rem", color: "#475569", fontSize: "1rem", fontWeight: 600 }}>
                        Процедуры
                    </h3>
                    {loadingProcs ? (
                        <p style={{ color: "#94a3b8", margin: 0 }}>Загрузка...</p>
                    ) : procedures.length === 0 ? (
                        <p style={{ color: "#94a3b8", margin: 0 }}>Нет данных</p>
                    ) : (
                        <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 10 }}>
                            {procedures.map(p => {
                                const status = getProcedureStatus(p);
                                return (
                                    <li key={p.procedureId} style={{ borderBottom: "1px solid #f1f5f9", paddingBottom: 8 }}>
                                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                                            <span style={{ fontWeight: 500, color: "#1e293b", fontSize: "0.9rem" }}>{p.title || "Процедура"}</span>
                                            <span style={{ fontSize: "0.75rem", fontWeight: 600, color: status.color, background: `${status.color}18`, padding: "2px 8px", borderRadius: 20 }}>
                                                {status.label}
                                            </span>
                                        </div>
                                        <div style={{ fontSize: "0.8rem", color: "#94a3b8", marginTop: 2 }}>
                                            {formatDate(p.scheduledDate)} · {p.price.toLocaleString("ru-RU")} ₽
                                        </div>
                                    </li>
                                );
                            })}
                        </ul>
                    )}
                    <Link to="/schedule" style={{ display: "block", marginTop: 12, fontSize: "0.85rem", color: "#3b82f6", textDecoration: "none" }}>
                        Перейти к расписанию →
                    </Link>
                </div>

                {/* Recent patients */}
                <div style={{ background: "white", borderRadius: 12, padding: "1.2rem", boxShadow: "0 2px 8px rgba(0,0,0,0.07)" }}>
                    <h3 style={{ margin: "0 0 1rem", color: "#475569", fontSize: "1rem", fontWeight: 600 }}>
                        Новые пациенты
                    </h3>
                    {loadingPats ? (
                        <p style={{ color: "#94a3b8", margin: 0 }}>Загрузка...</p>
                    ) : patients.length === 0 ? (
                        <p style={{ color: "#94a3b8", margin: 0 }}>Нет данных</p>
                    ) : (
                        <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 10 }}>
                            {patients.map(p => (
                                <li
                                    key={p.patientId}
                                    style={{ borderBottom: "1px solid #f1f5f9", paddingBottom: 8, cursor: "pointer" }}
                                    onClick={() => navigate(`/patients/${p.cardId}`)}
                                >
                                    <div style={{ fontWeight: 500, color: "#1e293b", fontSize: "0.9rem" }}>
                                        {p.fullname || "—"}
                                    </div>
                                    <div style={{ fontSize: "0.8rem", color: "#94a3b8", marginTop: 2 }}>
                                        {p.age ? `${p.age} лет · ` : ""}
                                        Добавлен {formatDate(p.creationDate)}
                                    </div>
                                </li>
                            ))}
                        </ul>
                    )}
                    <Link to="/patients" style={{ display: "block", marginTop: 12, fontSize: "0.85rem", color: "#3b82f6", textDecoration: "none" }}>
                        Все пациенты →
                    </Link>
                </div>

            </div>
        </div>
    );
};

export default HomePage;
