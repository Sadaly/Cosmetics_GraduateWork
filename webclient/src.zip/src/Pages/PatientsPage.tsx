import React, { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import type { PatientCard } from "../TypesFromServer/PatientCard";
import api from "../api/api";

const PatientsPage: React.FC = () => {
    const [patients, setPatients] = useState<PatientCard[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [newPatientName, setNewPatientName] = useState("");
    const [saving, setSaving] = useState(false);
    const [startIndex, setStartIndex] = useState(0);
    const [pageSize, setPageSize] = useState(10);
    const [hasMore, setHasMore] = useState(true);

    const [searchName, setSearchName] = useState("");
    const [creationDateFrom, setCreationDateFrom] = useState("");
    const [creationDateTo, setCreationDateTo] = useState("");

    const [draftName, setDraftName] = useState("");
    const [draftFrom, setDraftFrom] = useState("");
    const [draftTo, setDraftTo] = useState("");

    const navigate = useNavigate();
    const currentPage = Math.floor(startIndex / pageSize) + 1;

    const toUtcIsoDate = (dateString: string, endOfDay = false): string => {
        if (!dateString) return "";
        const time = endOfDay ? "T23:59:59Z" : "T00:00:00Z";
        return new Date(dateString + time).toISOString();
    };

    const fetchPatients = useCallback(async (
        start: number,
        count: number,
        name: string,
        from: string,
        to: string,
    ) => {
        setLoading(true);
        setError(null);
        try {
            const params: Record<string, any> = { StartIndex: start, Count: count };
            if (name.trim()) params.PatientName = name.trim();
            if (from) params.CreationDateFrom = toUtcIsoDate(from);
            if (to) params.CreationDateTo = toUtcIsoDate(to, true);

            const response = await api.get("/PatientCards/Take", { params });
            const data: PatientCard[] = Array.isArray(response.data) ? response.data : [];
            setPatients(data);
            setHasMore(data.length === count);
        } catch (err) {
            console.error("Ошибка загрузки пациентов", err);
            setError("Не удалось загрузить пациентов");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchPatients(startIndex, pageSize, searchName, creationDateFrom, creationDateTo);
    }, [startIndex, pageSize, searchName, creationDateFrom, creationDateTo, fetchPatients]);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        setSearchName(draftName);
        setCreationDateFrom(draftFrom);
        setCreationDateTo(draftTo);
        setStartIndex(0);
    };

    const handleClear = () => {
        setDraftName("");
        setDraftFrom("");
        setDraftTo("");
        setSearchName("");
        setCreationDateFrom("");
        setCreationDateTo("");
        setStartIndex(0);
    };

    const handleCreatePatient = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newPatientName.trim()) return alert("Введите ФИО пациента");
        setSaving(true);
        try {
            await api.post("/Patients", { fullname: newPatientName });
            setNewPatientName("");
            fetchPatients(startIndex, pageSize, searchName, creationDateFrom, creationDateTo);
        } catch (err) {
            console.error("Ошибка при создании пациента", err);
            alert("Не удалось создать пациента");
        } finally {
            setSaving(false);
        }
    };

    const handleDelete = async (patientId: string) => {
        if (!window.confirm("Удалить пациента?")) return;
        try {
            await api.delete(`/Patients/${patientId}`);
            setPatients(prev => prev.filter(p => p.patientId !== patientId));
        } catch (err) {
            console.error("Ошибка удаления пациента", err);
            alert("Ошибка при удалении");
        }
    };

    return (
        <div style={{ padding: "2rem" }}>
            <h1>Пациенты</h1>

            {/* Форма поиска */}
            <form
                onSubmit={handleSearch}
                style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginBottom: "1.5rem", alignItems: "center" }}
            >
                <input
                    type="text"
                    placeholder="Поиск по ФИО"
                    value={draftName}
                    onChange={e => setDraftName(e.target.value)}
                    style={{ padding: "8px", border: "1px solid #ccc", borderRadius: "4px", width: "200px" }}
                />
                <label>
                    С:
                    <input
                        type="date"
                        value={draftFrom}
                        onChange={e => setDraftFrom(e.target.value)}
                        style={{ marginLeft: "5px" }}
                    />
                </label>
                <label>
                    По:
                    <input
                        type="date"
                        value={draftTo}
                        onChange={e => setDraftTo(e.target.value)}
                        style={{ marginLeft: "5px" }}
                    />
                </label>
                <button
                    type="submit"
                    style={{ padding: "8px 12px", backgroundColor: "#0275d8", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}
                >
                    🔍 Найти
                </button>
                <button
                    type="button"
                    onClick={handleClear}
                    style={{ padding: "8px 12px", backgroundColor: "#6c757d", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}
                >
                    ✖ Очистить
                </button>
            </form>

            {/* Количество на странице */}
            <div style={{ marginBottom: "1rem" }}>
                <label htmlFor="pageSize" style={{ marginRight: "10px" }}>
                    Кол-во пациентов на странице: <strong>{pageSize}</strong>
                </label>
                <input
                    id="pageSize"
                    type="range"
                    min="1"
                    max="20"
                    value={pageSize}
                    onChange={e => { setPageSize(Number(e.target.value)); setStartIndex(0); }}
                    style={{ verticalAlign: "middle" }}
                />
            </div>

            {loading ? (
                <p>Загрузка...</p>
            ) : error ? (
                <p style={{ color: "red" }}>{error}</p>
            ) : patients.length === 0 ? (
                <p>Пациенты не найдены</p>
            ) : (
                <>
                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                        <thead>
                            <tr>
                                {["ФИО", "Возраст", "Телефон", "Жалобы", "Адрес", "Действия"].map(h => (
                                    <th key={h} style={{ borderBottom: "1px solid #ddd", padding: "8px", textAlign: "left" }}>{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {patients.map(p => (
                                <tr key={p.patientId}>
                                    <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>{p.fullname || "-"}</td>
                                    <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>{p.age || "-"}</td>
                                    <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>{p.phoneNumber || "-"}</td>
                                    <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>{p.complaints || "-"}</td>
                                    <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>{p.address || "-"}</td>
                                    <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                                        <button onClick={() => navigate(`/patients/${p.id}`)} style={{ marginRight: "10px" }}>
                                            Открыть
                                        </button>
                                        <button
                                            onClick={() => handleDelete(p.patientId)}
                                            style={{ backgroundColor: "#d9534f", color: "white", border: "none", borderRadius: "4px", padding: "4px 8px", cursor: "pointer" }}
                                        >
                                            Удалить
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>

                    {/* Пагинация */}
                    <div style={{ marginTop: "1rem", display: "flex", justifyContent: "center", alignItems: "center", gap: "12px" }}>
                        {startIndex > 0 && (
                            <button
                                onClick={() => setStartIndex(0)}
                                style={{ backgroundColor: "#0275d8", color: "white", borderRadius: "4px", padding: "4px 10px", border: "none", cursor: "pointer" }}
                            >
                                ⟳ В начало
                            </button>
                        )}
                        <button
                            disabled={startIndex === 0}
                            onClick={() => setStartIndex(Math.max(0, startIndex - pageSize))}
                        >
                            ← Назад
                        </button>
                        <span style={{ fontWeight: "bold" }}>Страница {currentPage}</span>
                        <button
                            disabled={!hasMore}
                            onClick={() => setStartIndex(startIndex + pageSize)}
                        >
                            Вперед →
                        </button>
                    </div>
                </>
            )}

            {/* Добавление пациента */}
            <form onSubmit={handleCreatePatient} style={{ display: "flex", gap: "10px", marginTop: "1.5rem" }}>
                <input
                    type="text"
                    placeholder="Введите ФИО"
                    value={newPatientName}
                    onChange={e => setNewPatientName(e.target.value)}
                    style={{ padding: "8px", border: "1px solid #ccc", borderRadius: "4px", flex: "1", maxWidth: "300px" }}
                />
                <button
                    type="submit"
                    disabled={saving}
                    style={{ padding: "8px 12px", backgroundColor: "#5cb85c", color: "white", border: "none", borderRadius: "4px", cursor: saving ? "wait" : "pointer" }}
                >
                    {saving ? "Добавление..." : "Добавить"}
                </button>
            </form>
        </div>
    );
};

export default PatientsPage;
