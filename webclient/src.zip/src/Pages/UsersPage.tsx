import React, { useEffect, useState } from "react";
import api from "../api/api";

interface UserItem {
    userId: string;
    username: string;
    email: string;
    registrationDate: string;
    updateDate: string;
}

const UsersPage: React.FC = () => {
    const [users, setUsers] = useState<UserItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    // Create form
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [creating, setCreating] = useState(false);
    const [createError, setCreateError] = useState<string | null>(null);
    const [createSuccess, setCreateSuccess] = useState(false);

    // Delete
    const [deletingId, setDeletingId] = useState<string | null>(null);

    // Pagination
    const [startIndex, setStartIndex] = useState(0);
    const pageSize = 10;
    const [hasMore, setHasMore] = useState(true);

    const fetchUsers = async (start: number) => {
        setLoading(true);
        setError(null);
        try {
            const r = await api.get("/Users/Take", { params: { StartIndex: start, Count: pageSize } });
            const data: UserItem[] = Array.isArray(r.data) ? r.data : [];
            setUsers(data);
            setHasMore(data.length === pageSize);
        } catch (e: any) {
            setError("Не удалось загрузить пользователей");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUsers(startIndex);
    }, [startIndex]);

    const handleCreate = async (e: React.FormEvent) => {
        e.preventDefault();
        setCreating(true);
        setCreateError(null);
        setCreateSuccess(false);
        try {
            await api.post("/Users/Register", { username, email, password });
            setUsername("");
            setEmail("");
            setPassword("");
            setCreateSuccess(true);
            // Reload list from start
            setStartIndex(0);
            fetchUsers(0);
        } catch (e: any) {
            const detail = e.response?.data?.detail || "Ошибка при создании пользователя";
            setCreateError(detail);
        } finally {
            setCreating(false);
        }
    };

    const handleDelete = async (userId: string) => {
        if (!window.confirm("Удалить пользователя?")) return;
        setDeletingId(userId);
        try {
            await api.delete(`/Users/${userId}`);
            setUsers(prev => prev.filter(u => u.userId !== userId));
        } catch (e: any) {
            const detail = e.response?.data?.detail || "Не удалось удалить пользователя";
            alert(detail);
        } finally {
            setDeletingId(null);
        }
    };

    const formatDate = (iso: string) => {
        const d = new Date(iso);
        return isNaN(d.getTime()) ? "—" : d.toLocaleString("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" });
    };

    const currentPage = Math.floor(startIndex / pageSize) + 1;

    return (
        <div style={{ padding: "2rem", maxWidth: 900, margin: "0 auto" }}>
            <h1 style={{ color: "#1e293b", marginBottom: "0.25rem" }}>Управление пользователями</h1>
            <p style={{ color: "#64748b", marginBottom: "2rem" }}>
                Создание учётных записей и управление доступом к системе.
            </p>

            {/* Create form */}
            <div style={{ background: "white", borderRadius: 12, padding: "1.5rem", boxShadow: "0 2px 8px rgba(0,0,0,0.07)", marginBottom: "2rem" }}>
                <h2 style={{ margin: "0 0 1.2rem", fontSize: "1.1rem", color: "#1e293b" }}>Создать пользователя</h2>
                <form onSubmit={handleCreate}>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "12px", marginBottom: "12px" }}>
                        <div>
                            <label style={{ display: "block", fontSize: "0.85rem", color: "#475569", marginBottom: 4 }}>Имя пользователя</label>
                            <input
                                type="text"
                                value={username}
                                onChange={e => setUsername(e.target.value)}
                                required
                                placeholder="Иванова А.В."
                                style={{ width: "100%", padding: "8px 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: "0.9rem", boxSizing: "border-box" }}
                            />
                        </div>
                        <div>
                            <label style={{ display: "block", fontSize: "0.85rem", color: "#475569", marginBottom: 4 }}>Email</label>
                            <input
                                type="email"
                                value={email}
                                onChange={e => setEmail(e.target.value)}
                                required
                                placeholder="user@clinic.ru"
                                style={{ width: "100%", padding: "8px 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: "0.9rem", boxSizing: "border-box" }}
                            />
                        </div>
                        <div>
                            <label style={{ display: "block", fontSize: "0.85rem", color: "#475569", marginBottom: 4 }}>Пароль</label>
                            <input
                                type="password"
                                value={password}
                                onChange={e => setPassword(e.target.value)}
                                required
                                placeholder="Минимум 6 символов"
                                style={{ width: "100%", padding: "8px 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: "0.9rem", boxSizing: "border-box" }}
                            />
                        </div>
                    </div>

                    {createError && (
                        <div style={{ color: "#dc2626", fontSize: "0.85rem", marginBottom: 10, background: "#fef2f2", padding: "8px 12px", borderRadius: 6 }}>
                            {createError}
                        </div>
                    )}
                    {createSuccess && (
                        <div style={{ color: "#16a34a", fontSize: "0.85rem", marginBottom: 10, background: "#f0fdf4", padding: "8px 12px", borderRadius: 6 }}>
                            Пользователь успешно создан.
                        </div>
                    )}

                    <button
                        type="submit"
                        disabled={creating}
                        style={{
                            padding: "9px 20px",
                            background: creating ? "#94a3b8" : "#3b82f6",
                            color: "white",
                            border: "none",
                            borderRadius: 6,
                            fontWeight: 600,
                            fontSize: "0.9rem",
                            cursor: creating ? "wait" : "pointer",
                        }}
                    >
                        {creating ? "Создание..." : "Создать"}
                    </button>
                </form>
            </div>

            {/* Users list */}
            <div style={{ background: "white", borderRadius: 12, padding: "1.5rem", boxShadow: "0 2px 8px rgba(0,0,0,0.07)" }}>
                <h2 style={{ margin: "0 0 1.2rem", fontSize: "1.1rem", color: "#1e293b" }}>Список пользователей</h2>

                {loading ? (
                    <p style={{ color: "#94a3b8" }}>Загрузка...</p>
                ) : error ? (
                    <p style={{ color: "#dc2626" }}>{error}</p>
                ) : users.length === 0 ? (
                    <p style={{ color: "#94a3b8" }}>Пользователи не найдены</p>
                ) : (
                    <>
                        <table style={{ width: "100%", borderCollapse: "collapse" }}>
                            <thead>
                                <tr style={{ background: "#f8fafc" }}>
                                    {["Имя", "Email", "Дата регистрации", ""].map(h => (
                                        <th key={h} style={{ textAlign: "left", padding: "10px 12px", fontSize: "0.8rem", color: "#64748b", fontWeight: 600, borderBottom: "1px solid #e2e8f0" }}>
                                            {h}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {users.map(u => (
                                    <tr key={u.userId} style={{ borderBottom: "1px solid #f1f5f9" }}>
                                        <td style={{ padding: "10px 12px", fontSize: "0.9rem", color: "#1e293b", fontWeight: 500 }}>{u.username}</td>
                                        <td style={{ padding: "10px 12px", fontSize: "0.9rem", color: "#475569" }}>{u.email}</td>
                                        <td style={{ padding: "10px 12px", fontSize: "0.85rem", color: "#94a3b8" }}>{formatDate(u.registrationDate)}</td>
                                        <td style={{ padding: "10px 12px", textAlign: "right" }}>
                                            <button
                                                onClick={() => handleDelete(u.userId)}
                                                disabled={deletingId === u.userId}
                                                style={{
                                                    padding: "5px 12px",
                                                    background: deletingId === u.userId ? "#fca5a5" : "#fee2e2",
                                                    color: "#dc2626",
                                                    border: "1px solid #fca5a5",
                                                    borderRadius: 5,
                                                    fontSize: "0.8rem",
                                                    fontWeight: 600,
                                                    cursor: deletingId === u.userId ? "wait" : "pointer",
                                                }}
                                            >
                                                {deletingId === u.userId ? "Удаление..." : "Удалить"}
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>

                        {/* Pagination */}
                        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 12, marginTop: 16 }}>
                            <button
                                disabled={startIndex === 0}
                                onClick={() => setStartIndex(Math.max(0, startIndex - pageSize))}
                                style={{ padding: "6px 14px", borderRadius: 5, border: "1px solid #cbd5e1", cursor: startIndex === 0 ? "default" : "pointer", background: "white" }}
                            >
                                ← Назад
                            </button>
                            <span style={{ fontSize: "0.9rem", color: "#64748b", fontWeight: 500 }}>Страница {currentPage}</span>
                            <button
                                disabled={!hasMore}
                                onClick={() => setStartIndex(startIndex + pageSize)}
                                style={{ padding: "6px 14px", borderRadius: 5, border: "1px solid #cbd5e1", cursor: !hasMore ? "default" : "pointer", background: "white" }}
                            >
                                Вперёд →
                            </button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default UsersPage;
