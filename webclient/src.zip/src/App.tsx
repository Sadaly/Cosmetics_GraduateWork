import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./Context/AuthContext";
import { ToastProvider } from "./Hooks/useToast";
import LoginPage from "./Pages/LoginPage";
import AnalyticsDashboardPage from "./Pages/AnalyticsDashboardPage";
import PatientDetailsPage from "./Pages/PatientDetailsPage";
import HomePage from "./Pages/HomePage";
import PatientsPage from "./Pages/PatientsPage";
import SchedulePage from "./Pages/SchedulePage";
import UsersPage from "./Pages/UsersPage";
import MainLayout from "./layouts/MainLayout";
import ErrorBoundary from "./ErrorHandlingMiddleware/ErrorBoundary";

const App: React.FC = () => {
    return (
        <AuthProvider>
        <ToastProvider>
        <ErrorBoundary>
            <Router>
                <Routes>
                    {/* Login — no layout */}
                    <Route path="/" element={<LoginPage />} />

                    {/* All pages under layout with header */}
                    <Route element={<MainLayout />}>
                        <Route path="/home" element={<HomePage />} />
                        <Route path="/patients" element={<PatientsPage />} />
                        <Route path="/patients/:id" element={<PatientDetailsPage />} />
                        <Route path="/schedule" element={<SchedulePage />} />
                        <Route path="/analitics" element={<AnalyticsDashboardPage />} />
                        <Route path="/users" element={<UsersPage />} />
                    </Route>
                </Routes>
            </Router>
        </ErrorBoundary>
        </ToastProvider>
        </AuthProvider>
    );
};

export default App;
