import React from 'react';

interface CardProps {
    children: React.ReactNode;
    className?: string;
    title?: string;
    subtitle?: string;
    action?: React.ReactNode;
    noPadding?: boolean;
}

export const Card: React.FC<CardProps> = ({
    children,
    className = '',
    title,
    subtitle,
    action,
    noPadding = false,
}) => (
    <div className={`card ${className}`}>
        {(title || subtitle || action) && (
            <div className="flex items-center justify-between gap-4 px-6 py-4"
                style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                <div>
                    {title && (
                        <h3 style={{
                            fontFamily: "'Cormorant Garamond', Georgia, serif",
                            fontSize: '1.125rem',
                            fontWeight: 600,
                            color: 'var(--text-primary)',
                        }}>
                            {title}
                        </h3>
                    )}
                    {subtitle && (
                        <p style={{ fontSize: '.8125rem', color: 'var(--text-muted)', marginTop: '.2rem' }}>
                            {subtitle}
                        </p>
                    )}
                </div>
                {action && <div className="shrink-0">{action}</div>}
            </div>
        )}
        {!noPadding && <div className="px-6 py-5">{children}</div>}
        {noPadding && children}
    </div>
);
